--[[ 
╔══════════════════════════════════════════════════[ www.hyperscripts.com.br ]═════════════════════════════════════════════════════════════╗
 ___  ___      ___    ___ ________  _______   ________          ________  ________  ________  ___  ________  _________  ________      
|\  \|\  \    |\  \  /  /|\   __  \|\  ___ \ |\   __  \        |\   ____\|\   ____\|\   __  \|\  \|\   __  \|\___   ___\\   ____\     
\ \  \\\  \   \ \  \/  / | \  \|\  \ \   __/|\ \  \|\  \       \ \  \___|\ \  \___|\ \  \|\  \ \  \ \  \|\  \|___ \  \_\ \  \___|_    
 \ \   __  \   \ \    / / \ \   ____\ \  \_|/_\ \   _  _\       \ \_____  \ \  \    \ \   _  _\ \  \ \   ____\   \ \  \ \ \_____  \   
  \ \  \ \  \   \/  /  /   \ \  \___|\ \  \_|\ \ \  \\  \|       \|____|\  \ \  \____\ \  \\  \\ \  \ \  \___|    \ \  \ \|____|\  \  
   \ \__\ \__\__/  / /      \ \__\    \ \_______\ \__\\ _\         ____\_\  \ \_______\ \__\\ _\\ \__\ \__\        \ \__\  ____\_\  \ 
    \|__|\|__|\___/ /        \|__|     \|_______|\|__|\|__|       |\_________\|_______|\|__|\|__|\|__|\|__|         \|__| |\_________\
             \|___|/                                              \|_________|                                            \|_________|
  
╚══════════════════════════════════════════════════[ www.hyperscripts.com.br ]═════════════════════════════════════════════════════════════╝
--]]

vehiclePanel = function()
    dxSetBlendMode('add')
    dxSetBlendMode('blend')
    drawRect(507, 532, 351, 177, 19, tocolor(48, 48, 48, 255), '#FF0000', 0, false)
    
    drawRect(525, 549, 45, 45, 6, tocolor(15, 15, 15, 255), '#FF0000', 0, false)
    drawRect(525, 599, 45, 45, 6, tocolor(15, 15, 15, 255), '#FF0000', 0, false)
    drawRect(525, 648, 45, 45, 6, tocolor(15, 15, 15, 255), '#FF0000', 0, false)

    drawRect(578, 599, 45, 45, 6, tocolor(15, 15, 15, 255), '#FF0000', 0, false)
    drawRect(578, 648, 45, 45, 6, tocolor(15, 15, 15, 255), '#FF0000', 0, false)

    drawRect(631, 549, 45, 45, 6, tocolor(15, 15, 15, 255), '#FF0000', 0, false)
    drawRect(631, 599, 45, 45, 6, tocolor(15, 15, 15, 255), '#FF0000', 0, false)
    drawRect(631, 648, 45, 45, 6, tocolor(15, 15, 15, 255), '#FF0000', 0, false)

    drawRect(684, 549, 45, 45, 6, tocolor(15, 15, 15, 255), '#FF0000', 0, false)
    drawRect(684, 599, 45, 45, 6, tocolor(15, 15, 15, 255), '#FF0000', 0, false)
    drawRect(684, 648, 45, 45, 6, tocolor(15, 15, 15, 255), '#FF0000', 0, false)

    drawRect(737, 549, 45, 45, 6, tocolor(15, 15, 15, 255), '#FF0000', 0, false)
    drawRect(737, 599, 45, 45, 6, tocolor(15, 15, 15, 255), '#FF0000', 0, false)
    drawRect(737, 648, 45, 45, 6, tocolor(15, 15, 15, 255), '#FF0000', 0, false)

    drawRect(790, 549, 45, 45, 6, tocolor(15, 15, 15, 255), '#FF0000', 0, false)
    drawRect(790, 599, 45, 45, 6, tocolor(15, 15, 15, 255), '#FF0000', 0, false)
    drawRect(790, 648, 45, 45, 6, tocolor(15, 15, 15, 255), '#FF0000', 0, false)

    cache.Dx.Image(503, 532, 359, 185, cache.Imagens["volta"], 0, 0, 0, tocolor(255, 255, 255, 255), false)


    -- Assento
    cache.Dx.Image(639, 606, 28, 28, cache.Imagens["assento"], 0, 0, 0, tocolor(255, 255, 255, 255), false)
    cache.Dx.Image(693, 606, 28, 28, cache.Imagens["assento"], 0, 0, 0, tocolor(255, 255, 255, 255), false)
    cache.Dx.Image(638, 655, 28, 28, cache.Imagens["assento"], 0, 0, 0, tocolor(255, 255, 255, 255), false)
    cache.Dx.Image(692, 655, 28, 28, cache.Imagens["assento"], 0, 0, 0, tocolor(255, 255, 255, 255), false)
    
    -- Portas Esquerda
    cache.Dx.Image(583, 603, 35, 35, cache.Imagens["porta"], 0, 0, 0, tocolor(255, 255, 255, 255), false)
    cache.Dx.Image(583, 652, 35, 35, cache.Imagens["porta"], 0, 0, 0, tocolor(255, 255, 255, 255), false)

    -- Portas Direita
    cache.Dx.Image(743, 603, 35, 35, cache.Imagens["portad"], 0, 0, 0, tocolor(255, 255, 255, 255), false)
    cache.Dx.Image(743, 652, 35, 35, cache.Imagens["portad"], 0, 0, 0, tocolor(255, 255, 255, 255), false)

    -- Engine
    cache.Dx.Image(536, 552, 23, 23, cache.Imagens["engine"], 0, 0, 0, tocolor(255, 255, 255, 255), false)
    cache.Dx.Text('START', 534, 570, 28, 11, tocolor(255, 255, 255, 255), 1, cache.Fonts["Fonte Mont Bold 8"], "center", "top", false, false, false, true, false)
    cache.Dx.Text('STOP', 534, 580, 28, 11, tocolor(255, 255, 255, 255), 1, cache.Fonts["Fonte Mont Bold 8"], "center", "top", false, false, false, true, false)

    -- Capo
    cache.Dx.Image(635, 552, 38, 38, cache.Imagens["capo"], 0, 0, 0, tocolor(255, 255, 255, 255), false)
    -- Malas
    cache.Dx.Image(685, 550, 42, 42, cache.Imagens["malas"], 0, 0, 0, tocolor(255, 255, 255, 255), false)
    -- Tranca 
    cache.Dx.Image(744, 557, 31, 31, cache.Imagens["tranca"], 0, 0, 0, tocolor(255, 255, 255, 255), false)
    -- Luz
    cache.Dx.Image(799, 557, 27, 27, cache.Imagens["luz"], 0, 0, 0, tocolor(255, 255, 255, 255), false)
    -- Vidros
    cache.Dx.Image(520, 607, 53, 31, cache.Imagens["vidro"], 0, 0, 0, tocolor(255, 255, 255, 255), false)
    cache.Dx.Image(520, 655, 53, 31, cache.Imagens["vidro"], 0, 0, 0, tocolor(255, 255, 255, 255), false)
    cache.Dx.Image(786, 607, 53, 31, cache.Imagens["vidrod"], 0, 0, 0, tocolor(255, 255, 255, 255), false)
    cache.Dx.Image(786, 655, 53, 31, cache.Imagens["vidrod"], 0, 0, 0, tocolor(255, 255, 255, 255), false)


end


cache.functions.register('PainelVeh', getRootElement(), function(player)
    if not cache.functions.EventoAtivo("onClientRender", getRootElement(), vehiclePanel) then
        showCursor(true)
        addEventHandler("onClientRender", getRootElement(), vehiclePanel)
    else
        showCursor(false)
        removeEventHandler("onClientRender", getRootElement(), vehiclePanel)
    end
end)

local seatWindows = {
	[0] = 4,
	[1] = 2,
	[2] = 5,
	[3] = 3
}

addEventHandler ( "onClientClick", getRootElement(),
function  ( button, state )
    if cache.functions.EventoAtivo("onClientRender", getRootElement(), vehiclePanel) then  
        if button == "left" and state == "down" then
            if cache.functions.Cursor(525, 549, 45, 45) then
                triggerServerEvent("VehicleFunction", getLocalPlayer(), localPlayer, "engine")
            elseif cache.functions.Cursor(525, 599, 45, 45) then
                local veh = getPedOccupiedVehicle( localPlayer )
                if veh then
                    if seatWindows[0] and setVehicleWindowOpen( veh, seatWindows[0], not isVehicleWindowOpen( veh, seatWindows[0] ) ) then
                        triggerServerEvent("Infobox", getLocalPlayer(), localPlayer, "Você abriu o vidro.", 'success')
                    else
                        triggerServerEvent("Infobox", getLocalPlayer(), localPlayer, "Vidro nao existe", 'error')
                    end
                end
            elseif cache.functions.Cursor(525, 648, 45, 45) then
                local veh = getPedOccupiedVehicle( localPlayer )
                if veh then
                    if seatWindows[2] and setVehicleWindowOpen( veh, seatWindows[2], not isVehicleWindowOpen( veh, seatWindows[2] ) ) then
                        triggerServerEvent("Infobox", getLocalPlayer(), localPlayer, "Você abriu o vidro.", 'success')
                    else
                        triggerServerEvent("Infobox", getLocalPlayer(), localPlayer, "Vidro nao existe", 'error')
                    end
                end
            elseif cache.functions.Cursor(578, 599, 45, 45) then
                if not TimePorta1 then
                    TimePorta1 = true
                    triggerServerEvent("VehicleFunction", getLocalPlayer(), localPlayer, "portas", 2)
                    setTimer(function()
                        TimePorta1 = nil
                    end, 2500, 1)
                end
            elseif cache.functions.Cursor(578, 648, 45, 45) then
                if not TimePorta2 then
                    TimePorta2 = true
                    triggerServerEvent("VehicleFunction", getLocalPlayer(), localPlayer, "portas", 4)
                    setTimer(function()
                        TimePorta2 = nil
                    end, 2500, 1)
                end
            elseif cache.functions.Cursor(631, 549, 45, 45) then
                if not TimeCapo then
                    TimeCapo = true
                    triggerServerEvent("VehicleFunction", getLocalPlayer(), localPlayer, "portas", 0)
                    setTimer(function()
                        TimeCapo = nil
                    end, 2500, 1)
                end
            elseif cache.functions.Cursor(631, 599, 45, 45) then
                triggerServerEvent("VehicleFunction", getLocalPlayer(), localPlayer, "assento", 0)
            elseif cache.functions.Cursor(631, 648, 45, 45) then
                triggerServerEvent("VehicleFunction", getLocalPlayer(), localPlayer, "assento", 2)
            elseif cache.functions.Cursor(684, 549, 45, 45) then
                if not TimeMalas then
                    TimeMalas = true
                    triggerServerEvent("VehicleFunction", getLocalPlayer(), localPlayer, "portas", 1)
                    setTimer(function()
                        TimeMalas = nil
                    end, 2500, 1)
                end
            elseif cache.functions.Cursor(684, 599, 45, 45) then
                triggerServerEvent("VehicleFunction", getLocalPlayer(), localPlayer, "assento", 1)
            elseif cache.functions.Cursor(684, 648, 45, 45) then
                triggerServerEvent("VehicleFunction", getLocalPlayer(), localPlayer, "assento", 3)
            elseif cache.functions.Cursor(737, 549, 45, 45) then
                triggerServerEvent("VehicleFunction", getLocalPlayer(), localPlayer, "lock")
            elseif cache.functions.Cursor(737, 599, 45, 45) then
                if not TimePorta3 then
                    TimePorta3 = true
                    triggerServerEvent("VehicleFunction", getLocalPlayer(), localPlayer, "portas", 3)
                    setTimer(function()
                        TimePorta3 = nil
                    end, 2500, 1)
                end
            elseif cache.functions.Cursor(737, 648, 45, 45) then
                if not TimePorta4 then
                    TimePorta4 = true
                    triggerServerEvent("VehicleFunction", getLocalPlayer(), localPlayer, "portas", 5)
                    setTimer(function()
                        TimePorta4 = nil
                    end, 2500, 1)
                end
            elseif cache.functions.Cursor(790, 549, 45, 45) then
                triggerServerEvent("VehicleFunction", getLocalPlayer(), localPlayer, "light")
            elseif cache.functions.Cursor(790, 599, 45, 45) then
                local veh = getPedOccupiedVehicle( localPlayer )
                if veh then
                    if seatWindows[1] and setVehicleWindowOpen( veh, seatWindows[1], not isVehicleWindowOpen( veh, seatWindows[1] ) ) then
                        triggerServerEvent("Infobox", getLocalPlayer(), localPlayer, "Você abriu o vidro.", 'success')
                    else
                        triggerServerEvent("Infobox", getLocalPlayer(), localPlayer, "Vidro nao existe", 'error')
                    end
                end
            elseif cache.functions.Cursor(790, 648, 45, 45) then
                local veh = getPedOccupiedVehicle( localPlayer )
                if veh then
                    if seatWindows[3] and setVehicleWindowOpen( veh, seatWindows[3], not isVehicleWindowOpen( veh, seatWindows[3] ) ) then
                        triggerServerEvent("Infobox", getLocalPlayer(), localPlayer, "Você abriu o vidro.", 'success')
                    else
                        triggerServerEvent("Infobox", getLocalPlayer(), localPlayer, "Vidro nao existe", 'error')
                    end
                end
            end
        end
    end
end)

bindKey("e", "down", function()
    local vehicle = getPedOccupiedVehicle(localPlayer) or getNearestVehicle(5)

    if vehicle and isElement(vehicle) then
        triggerServerEvent("VehicleFunction", localPlayer, vehicle, "lock")
    else
        outputChatBox("Você precisa estar próximo de um veículo para travá-lo.", 255, 0, 0)
    end
end)

function getNearestVehicle(radius)
    local px, py, pz = getElementPosition(localPlayer)
    local nearestVeh = nil
    local shortestDist = radius

    for _, veh in ipairs(getElementsByType("vehicle")) do
        local vx, vy, vz = getElementPosition(veh)
        local dist = getDistanceBetweenPoints3D(px, py, pz, vx, vy, vz)
        if dist < shortestDist then
            nearestVeh = veh
            shortestDist = dist
        end
    end

    return nearestVeh
end