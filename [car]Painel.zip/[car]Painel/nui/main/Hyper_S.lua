--[[ 
╔══════════════════════════════════════════════════[ www.hyperscripts.com.br ]═════════════════════════════════════════════════════════════╗
 ___  ___      ___    ___ ________  _______   ________          ________  ________  ________  ___  ________  _________  ________      
|\  \|\  \    |\  \  /  /|\   __  \|\  ___ \ |\   __  \        |\   ____\|\   ____\|\   __  \|\  \|\   __  \|\___   ___\\   ____\     
\ \  \\\  \   \ \  \/  / | \  \|\  \ \   __/|\ \  \|\  \       \ \  \___|\ \  \___|\ \  \|\  \ \  \ \  \|\  \|___ \  \_\ \  \___|_    
 \ \   __  \   \ \    / / \ \   ____\ \  \_|/_\ \   _  _\       \ \_____  \ \  \    \ \   _  _\ \  \ \   ____\   \ \  \ \ \_____  \   
  \ \  \ \  \   \/  /  /   \ \  \___|\ \  \_|\ \ \  \\  \|       \|____|\  \ \  \____\ \  \\  \\ \  \ \  \___|    \ \  \ \|____|\  \  
   \ \__\ \__\__/  / /      \ \__\    \ \_______\ \__\\ _\         ____\_\  \ \_______\ \__\\ _\\ \__\ \__\        \ \__\  ____\_\  \ 
    \|__|\|__|\___/ /        \|__|     \|_______|\|__|\|__|       |\_________\|_______|\|__|\|__|\|__|\|__|         \|__| |\_________\
             \|___|/                                              \|_________|                                            \|_________|
  
╚══════════════════════════════════════════════════[ www.hyperscripts.com.br ]═════════════════════════════════════════════════════════════╝
--]]

addEventHandler("onPlayerLogin", getRootElement ( ),
function()
    bindKey(source, tostring(Hyper_Confgs['Bind']), "down", PaivelVehicle)
end)

addEventHandler("onResourceStart", resourceRoot,
function()
    for i, player in ipairs (getElementsByType("player")) do
        bindKey(player, tostring(Hyper_Confgs['Bind']), "down", PaivelVehicle)
    end
end)


PaivelVehicle = function(player)
    local vehicle = getPedOccupiedVehicle(player)
    if vehicle then
        local id = getElementModel ( vehicle ) 
        for i, v in ipairs(Hyper_Confgs['ID Veiculos']) do
            if v == id then
                return  outputMessage(player, "esse veiculo não pode abrir o painel", "success")
            end
        end
        triggerClientEvent( player, "PainelVeh", player)
    else
        outputMessage(player, "Entre em um veiculo para abrir o painel!", "success")
    end
end

cache.functions.register('Infobox', getRootElement(), function(player, msg, type)
    outputMessage(player, msg, type)
end)

cache.functions.register("VehicleFunction", getRootElement(), function(player, type, slot)
    local vehicle = getPedOccupiedVehicle ( player )
    if vehicle then
        if type == "light" then
            local seat = getPedOccupiedVehicleSeat( player )
            if seat == 0 then
                if getVehicleOverrideLights(vehicle) ~= 2 then
                    setVehicleOverrideLights(vehicle, 2)
                    outputMessage(player, "Você ligou a luz do veiculo", "success")
                    else
                        setVehicleOverrideLights(vehicle, 1)
                        outputMessage(player, "Você desligou a luz do veiculo", "success")
                        end
                    end
                elseif type == "engine" then
                    local seat = getPedOccupiedVehicleSeat( player )
                    if seat == 0 then
                        if getElementHealth(vehicle) < Hyper_Confgs['Minimo De Vida Veiculo'] then
                            setVehicleEngineState(vehicle, false)
                            outputMessage(player, "O seu veiculo esta quebrado!", "success")
                        else
                            if getVehicleEngineState(vehicle) then
                                setVehicleEngineState(vehicle, false)
                                outputMessage(player, "Você desligou o veiculo", "success")
                            else
                                setVehicleEngineState(vehicle, true)
                                outputMessage(player, "Você ligou o veiculo", "success")
                            end
                        end
                    end
                elseif type == "lock" then
                    local seat = getPedOccupiedVehicleSeat(player)
                    if seat == 0 then
                        if getElementData(player, "ID") == getElementData(vehicle, "owner_id") then
                            if isVehicleLocked(vehicle) then
                                outputMessage(player, "Você destrancou o veiculo", "success")
                                setVehicleLocked(vehicle, false)
                            else
                                outputMessage(player, "Você trancou o veiculo", "success")
                                setVehicleLocked(vehicle, true) 
                            end
                        else
                            outputMessage(player, "Este carro não é teu.", "success")
                        end
                    end
                elseif type == "portas"then
                    outputMessage(player, "Você Abriu a porta", "success")
                    setVehicleDoorOpenRatio(vehicle, slot, 1 - getVehicleDoorOpenRatio ( vehicle, slot ), 2500)
                elseif type == "assento" then
                    local seat = getPedOccupiedVehicleSeat(player)
                    if isVehicleLocked(vehicle) then
                        if not getVehicleOccupant(vehicle, slot) then
                            outputMessage(player, "Você mudou de assento", "success")
                            warpPedIntoVehicle(player, vehicle, slot)
                        end
                    else
                        outputMessage(player, "Não podes trocar de lugar com o carro trancado.", "success")
                    end
                end
            end
        end)