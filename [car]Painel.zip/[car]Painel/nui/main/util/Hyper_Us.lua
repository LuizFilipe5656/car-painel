
----- Utils ----

_event = addEvent
_eventH = addEventHandler
cache = {
    functions = {},
}


cache.functions.register =
function(event, ...)
    _event(event, true)
    _eventH(event, ...)
end

addEvent("VehicleFunction", true)
addEventHandler("VehicleFunction", root, function(vehicle, action)
    if action == "lock" and isElement(vehicle) and getElementType(vehicle) == "vehicle" then
        local locked = isVehicleLocked(vehicle)
        setVehicleLocked(vehicle, not locked)

    
        outputChatBox("Veículo " .. (locked and "destravado" or "travado") .. ".", source, 0, 255, 0)
    end
end)
