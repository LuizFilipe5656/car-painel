--[[ 
╔══════════════════════════════════════════════════[ www.hyperscripts.com.br ]═════════════════════════════════════════════════════════════╗
 ___  ___      ___    ___ ________  _______   ________          ________  ________  ________  ___  ________  _________  ________      
|\  \|\  \    |\  \  /  /|\   __  \|\  ___ \ |\   __  \        |\   ____\|\   ____\|\   __  \|\  \|\   __  \|\___   ___\\   ____\     
\ \  \\\  \   \ \  \/  / | \  \|\  \ \   __/|\ \  \|\  \       \ \  \___|\ \  \___|\ \  \|\  \ \  \ \  \|\  \|___ \  \_\ \  \___|_    
 \ \   __  \   \ \    / / \ \   ____\ \  \_|/_\ \   _  _\       \ \_____  \ \  \    \ \   _  _\ \  \ \   ____\   \ \  \ \ \_____  \   
  \ \  \ \  \   \/  /  /   \ \  \___|\ \  \_|\ \ \  \\  \|       \|____|\  \ \  \____\ \  \\  \\ \  \ \  \___|    \ \  \ \|____|\  \  
   \ \__\ \__\__/  / /      \ \__\    \ \_______\ \__\\ _\         ____\_\  \ \_______\ \__\\ _\\ \__\ \__\        \ \__\  ____\_\  \ 
    \|__|\|__|\___/ /        \|__|     \|_______|\|__|\|__|       |\_________\|_______|\|__|\|__|\|__|\|__|         \|__| |\_________\
             \|___|/                                              \|_________|                                            \|_________|
  
╚══════════════════════════════════════════════════[ www.hyperscripts.com.br ]═════════════════════════════════════════════════════════════╝
--]]

 
----- Utils ----
screen = { guiGetScreenSize() }
resW, resH = 1366, 768
sx, sy = screen[1]/resW, screen[2]/resH
 
function aToR(X, Y, sX, sY)

    local xd = X/resW or X

    local yd = Y/resH or Y

    local xsd = sX/resW or sX

    local ysd = sY/resH or sY

    return xd * screen[1], yd * screen[2], xsd * screen[1], ysd * screen[2]
    
end

_dxDrawRectangle = dxDrawRectangle

function dxDrawRectangle(x, y, w, h, ...)

    local x, y, w, h = aToR(x, y, w, h)

    return _dxDrawRectangle(x, y, w, h, ...)

end

_dxDrawText = dxDrawText

function dxDrawText(text, x, y, w, h, ...)

    local x, y, w, h = aToR(x, y, w, h)

    return _dxDrawText(text, x, y, w + x, h + y, ...)

end

_dxDrawImage = dxDrawImage

function dxDrawImage(x, y, w, h, ...)

    local x, y, w, h = aToR(x, y, w, h)

    return _dxDrawImage(x, y, w, h, ...)

end

_dxCreateFont = dxCreateFont

function dxCreateFont( filePath, size, ... )

    return _dxCreateFont( filePath, ( sx * size ), ... )

end

_event = addEvent
_eventH = addEventHandler
cache = {
    
    functions = {},
    EditBox = {},
    Dx = {
        Image = dxDrawImage,
        Retangulo = dxDrawRectangle,
        Text = dxDrawText,
    },
    Fonts = {
        
        ["Fonte Mont Bold 8"] = dxCreateFont("nui/fonts/Montserrat-Bold.ttf", 7, false, "cleartype_natural" ) or 'default',
        ["Fonte Mont Itali Bold"] = dxCreateFont("nui/fonts/Montserrat-Bold.ttf", 10, false, "cleartype_natural" ) or 'default',
        ["Fonte Mont Itali Bold 15"] = dxCreateFont("nui/fonts/Montserrat-Bold.ttf", 15, false, "cleartype_natural" ) or 'default',
        ["Fonte Mont Itali Bold velo"] = dxCreateFont("nui/fonts/Montserrat-Bold.ttf", 30, false, "cleartype_natural" ) or 'default',
        
    },
    Imagens = {
        
        ["assento"] = dxCreateTexture( "nui/images/assento.png", 'dxt5', true, 'clamp'),
        ["capo"] = dxCreateTexture( "nui/images/capo.png", 'dxt5', true, 'clamp'),
        ["engine"] = dxCreateTexture( "nui/images/engine.png", 'dxt5', true, 'clamp'),
        ["luz"] = dxCreateTexture( "nui/images/luz.png", 'dxt5', true, 'clamp'),
        ["malas"] = dxCreateTexture( "nui/images/malas.png", 'dxt5', true, 'clamp'),
        ["porta"] = dxCreateTexture( "nui/images/porta.png", 'dxt5', true, 'clamp'),
        ["portad"] = dxCreateTexture( "nui/images/portad.png", 'dxt5', true, 'clamp'),
        ["tranca"] = dxCreateTexture( "nui/images/tranca.png", 'dxt5', true, 'clamp'),
        ["vidro"] = dxCreateTexture( "nui/images/vidro.png", 'dxt5', true, 'clamp'),
        ["vidrod"] = dxCreateTexture( "nui/images/vidrod.png", 'dxt5', true, 'clamp'),
        ["volta"] = dxCreateTexture( "nui/images/volta.png", 'dxt5', true, 'clamp'),
        
    },
}


cache.functions.register =
function(event, ...)
    _event(event, true)
    _eventH(event, ...)
end

cache.functions.Cursor = 
function(x,y,w,h)
    local x, y, w, h = aToR(x, y, w, h)
    if isCursorShowing() then
        local mx, my = getCursorPosition()
        local resx, resy = guiGetScreenSize()
        mousex, mousey = mx * resx, my * resy
        if mousex > x and mousex < x + w and mousey > y and mousey < y + h then
            return true
        else
            return false
        end
    end
end

cache.functions.EventoAtivo = 
function ( sEventName, pElementAttachedTo, func )
    if type( sEventName ) == 'string' and isElement( pElementAttachedTo ) and type( func ) == 'function' then
        local aAttachedFunctions = getEventHandlers( sEventName, pElementAttachedTo )
        if type( aAttachedFunctions ) == 'table' and #aAttachedFunctions > 0 then
            for i, v in ipairs( aAttachedFunctions ) do
                if v == func then
                    return true
                end
            end
        end
    end
    return false
end

local buttons = {}

function drawRect(x, y, width, height, radius, color, colorStroke, sizeStroke, postGUI)
    colorStroke = tostring(colorStroke)
    sizeStroke = tostring(sizeStroke)
    
    if (not buttons[radius]) then
        local raw = string.format([[
        <svg width='%s' height='%s' fill='none' xmlns='http://www.w3.org/2000/svg'>
        <mask id='path_inside' fill='#FFFFFF' >
        <rect width='%s' height='%s' rx='%s' />
        </mask>
        <rect opacity='1' width='%s' height='%s' rx='%s' fill='#FFFFFF' stroke='%s' stroke-width='%s' mask='url(#path_inside)'/>
        </svg>
        ]], width, height, width, height, radius, width, height, radius, colorStroke, sizeStroke)
        buttons[radius] = svgCreate(width, height, raw)
    end
    if (buttons[radius]) then -- Se já existir um botão com o mesmo Radius, reaproveitaremos o mesmo, para não criar outro.
        dxDrawImage(x, y, width, height, buttons[radius], 0, 0, 0, color, postGUI)
    end
end